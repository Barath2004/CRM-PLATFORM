import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Menu, 
  Bell, 
  Search, 
  LogOut,
  User,
  Settings,
  HelpCircle,
  MessageSquare,
  Users,
  LayoutDashboard,
  ChevronDown
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const Header: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  return (
    <header className="bg-white border-b border-gray-200 shadow-sm z-10">
      <div className="px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center md:hidden">
            <button
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary"
            >
              <Menu size={24} />
            </button>
          </div>
          
          <div className="md:hidden">
            <Link to="/" className="flex items-center">
              <h1 className="text-xl font-bold text-primary">CRM Platform</h1>
            </Link>
          </div>
          
          <div className="hidden md:flex md:flex-1 md:items-center">
            <div className="relative w-64">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={18} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search..."
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md text-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button className="relative p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full">
              <Bell size={20} />
              <span className="absolute top-1 right-1 block h-2 w-2 rounded-full bg-red-500"></span>
            </button>
            
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center gap-2 focus:outline-none"
              >
                {user?.picture ? (
                  <img
                    src={user.picture}
                    alt={user.name}
                    className="h-8 w-8 rounded-full"
                  />
                ) : (
                  <div className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center">
                    {user?.name?.charAt(0) || 'U'}
                  </div>
                )}
                <span className="hidden md:block text-sm font-medium text-gray-700 truncate max-w-[100px]">
                  {user?.name}
                </span>
                <ChevronDown size={16} className="text-gray-500" />
              </button>
              
              {showUserMenu && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20 border border-gray-200">
                  <div className="px-4 py-2 text-xs text-gray-500 border-b border-gray-200 md:hidden">
                    {user?.email}
                  </div>
                  <button
                    onClick={() => {
                      setShowUserMenu(false);
                      navigate('/profile');
                    }}
                    className="flex items-center w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    <User size={16} className="mr-2" />
                    <span>Profile</span>
                  </button>
                  <button
                    onClick={() => {
                      setShowUserMenu(false);
                      navigate('/settings');
                    }}
                    className="flex items-center w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    <Settings size={16} className="mr-2" />
                    <span>Settings</span>
                  </button>
                  <button
                    onClick={handleLogout}
                    className="flex items-center w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    <LogOut size={16} className="mr-2" />
                    <span>Logout</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {showMobileMenu && (
        <div className="md:hidden border-t border-gray-200">
          <div className="pt-2 pb-3 space-y-1">
            <Link
              to="/"
              className="flex items-center px-4 py-2 text-base font-medium text-gray-900 hover:bg-gray-100"
              onClick={() => setShowMobileMenu(false)}
            >
              <LayoutDashboard size={20} className="mr-3" />
              Dashboard
            </Link>
            <Link
              to="/campaigns"
              className="flex items-center px-4 py-2 text-base font-medium text-gray-900 hover:bg-gray-100"
              onClick={() => setShowMobileMenu(false)}
            >
              <MessageSquare size={20} className="mr-3" />
              Campaigns
            </Link>
            <Link
              to="/customers"
              className="flex items-center px-4 py-2 text-base font-medium text-gray-900 hover:bg-gray-100"
              onClick={() => setShowMobileMenu(false)}
            >
              <Users size={20} className="mr-3" />
              Customers
            </Link>
            <Link
              to="/create-segment"
              className="flex items-center px-4 py-2 text-base font-medium text-gray-900 hover:bg-gray-100"
              onClick={() => setShowMobileMenu(false)}
            >
              <Users size={20} className="mr-3" />
              Create Segment
            </Link>
            <Link
              to="/settings"
              className="flex items-center px-4 py-2 text-base font-medium text-gray-900 hover:bg-gray-100"
              onClick={() => setShowMobileMenu(false)}
            >
              <Settings size={20} className="mr-3" />
              Settings
            </Link>
            <Link
              to="/help"
              className="flex items-center px-4 py-2 text-base font-medium text-gray-900 hover:bg-gray-100"
              onClick={() => setShowMobileMenu(false)}
            >
              <HelpCircle size={20} className="mr-3" />
              Help & Support
            </Link>
          </div>
          
          <div className="pt-4 pb-3 border-t border-gray-200">
            <div className="px-4 flex items-center">
              {user?.picture ? (
                <img
                  src={user.picture}
                  alt={user.name}
                  className="h-10 w-10 rounded-full"
                />
              ) : (
                <div className="h-10 w-10 rounded-full bg-primary text-white flex items-center justify-center">
                  {user?.name?.charAt(0) || 'U'}
                </div>
              )}
              <div className="ml-3">
                <div className="text-base font-medium text-gray-800">{user?.name}</div>
                <div className="text-sm font-medium text-gray-500">{user?.email}</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;