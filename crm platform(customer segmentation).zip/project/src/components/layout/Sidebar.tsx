import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  MessageSquare, 
  Users, 
  Settings, 
  HelpCircle,
  UserPlus
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const Sidebar: React.FC = () => {
  const { user } = useAuth();
  
  const navItems = [
    { to: '/', icon: <LayoutDashboard size={20} />, label: 'Dashboard' },
    { to: '/campaigns', icon: <MessageSquare size={20} />, label: 'Campaigns' },
    { to: '/customers', icon: <Users size={20} />, label: 'Customers' },
    { to: '/create-segment', icon: <UserPlus size={20} />, label: 'Create Segment' },
  ];
  
  return (
    <aside className="w-64 hidden md:block bg-white border-r border-gray-200 shadow-sm">
      <div className="h-full flex flex-col">
        <div className="px-6 py-6 border-b border-gray-200">
          <h1 className="text-2xl font-bold text-primary">CRM Platform</h1>
          <p className="text-sm text-gray-500">Customer Management</p>
        </div>
        
        {user && (
          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center gap-3">
              {user.picture ? (
                <img 
                  src={user.picture} 
                  alt={user.name} 
                  className="w-10 h-10 rounded-full"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center">
                  {user.name.charAt(0)}
                </div>
              )}
              <div className="overflow-hidden">
                <p className="font-medium truncate">{user.name}</p>
                <p className="text-xs text-gray-500 truncate">{user.email}</p>
              </div>
            </div>
          </div>
        )}
        
        <nav className="flex-1 py-4 overflow-y-auto">
          <ul className="space-y-1 px-3">
            {navItems.map((item) => (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  className={({ isActive }) =>
                    `flex items-center px-3 py-2 rounded-md transition-colors ${
                      isActive
                        ? 'bg-primary text-white'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`
                  }
                >
                  {item.icon}
                  <span className="ml-3">{item.label}</span>
                </NavLink>
              </li>
            ))}
          </ul>
          
          <div className="mt-auto pt-4 px-3 border-t border-gray-200 mt-6">
            <ul className="space-y-1">
              <li>
                <NavLink
                  to="/settings"
                  className="flex items-center px-3 py-2 rounded-md text-gray-700 hover:bg-gray-100 transition-colors"
                >
                  <Settings size={20} />
                  <span className="ml-3">Settings</span>
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/help"
                  className="flex items-center px-3 py-2 rounded-md text-gray-700 hover:bg-gray-100 transition-colors"
                >
                  <HelpCircle size={20} />
                  <span className="ml-3">Help & Support</span>
                </NavLink>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </aside>
  );
};

export default Sidebar;