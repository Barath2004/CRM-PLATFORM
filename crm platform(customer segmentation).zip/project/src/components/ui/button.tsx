import React from 'react';

type ButtonVariant = 
  | 'primary' 
  | 'secondary' 
  | 'outline' 
  | 'ghost' 
  | 'link' 
  | 'danger'
  | 'success'
  | 'gradient';

type ButtonSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

export type ButtonProps = {
  variant?: ButtonVariant;
  size?: ButtonSize;
  isLoading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  fullWidth?: boolean;
  animate?: boolean;
  glassmorphic?: boolean;
} & React.ButtonHTMLAttributes<HTMLButtonElement>;

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className = '',
      variant = 'primary',
      size = 'md',
      isLoading = false,
      disabled = false,
      leftIcon,
      rightIcon,
      children,
      fullWidth = false,
      animate = true,
      glassmorphic = false,
      ...props
    },
    ref
  ) => {
    const variantClasses = {
      primary: 'bg-primary text-white hover:bg-primary/90 focus:ring-primary/20',
      secondary: 'bg-secondary text-white hover:bg-secondary/90 focus:ring-secondary/20',
      outline: 'border-2 border-gray-300 text-gray-700 hover:bg-gray-50 focus:ring-gray-200',
      ghost: 'text-gray-700 hover:bg-gray-100 focus:ring-gray-200',
      link: 'text-primary underline-offset-4 hover:underline',
      danger: 'bg-red-600 text-white hover:bg-red-700 focus:ring-red-200',
      success: 'bg-green-600 text-white hover:bg-green-700 focus:ring-green-200',
      gradient: 'bg-gradient-to-r from-primary via-primary/90 to-secondary text-white hover:shadow-lg'
    };

    const sizeClasses = {
      xs: 'px-2 py-1 text-xs',
      sm: 'px-3 py-1.5 text-sm',
      md: 'px-4 py-2',
      lg: 'px-5 py-2.5 text-lg',
      xl: 'px-6 py-3 text-xl'
    };

    const glassmorphicClass = glassmorphic ? 'backdrop-blur-sm bg-opacity-80' : '';
    const animateClass = animate ? 'transform active:scale-95 transition-all duration-75' : '';
    const widthClass = fullWidth ? 'w-full' : '';

    return (
      <button
        ref={ref}
        disabled={disabled || isLoading}
        className={`
          inline-flex items-center justify-center font-medium rounded-md 
          focus:outline-none focus:ring-2 focus:ring-offset-2
          transition-colors duration-200
          disabled:opacity-50 disabled:cursor-not-allowed
          ${variantClasses[variant]}
          ${sizeClasses[size]}
          ${glassmorphicClass}
          ${animateClass}
          ${widthClass}
          ${className}
        `}
        {...props}
      >
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="animate-spin rounded-full h-5 w-5 border-2 border-current border-t-transparent" />
          </div>
        )}
        <span className={`flex items-center ${isLoading ? 'opacity-0' : ''}`}>
          {leftIcon && <span className="mr-2">{leftIcon}</span>}
          {children}
          {rightIcon && <span className="ml-2">{rightIcon}</span>}
        </span>
      </button>
    );
  }
);

Button.displayName = 'Button';