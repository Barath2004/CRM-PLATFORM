import React from 'react';

type CardProps = {
  className?: string;
  children: React.ReactNode;
  variant?: 'default' | 'glass' | 'gradient' | 'outline';
  animate?: boolean;
};

export const Card: React.FC<CardProps> = ({ 
  className = '', 
  children, 
  variant = 'default',
  animate = false 
}) => {
  const variants = {
    default: 'bg-white border border-gray-200 shadow-sm',
    glass: 'bg-white/80 backdrop-blur-lg border border-white/20',
    gradient: 'bg-gradient-to-br from-white via-white/95 to-white/90 border border-gray-200',
    outline: 'border-2 border-gray-200 bg-transparent hover:bg-white/50 transition-colors'
  };

  return (
    <div 
      className={`
        rounded-lg 
        ${variants[variant]}
        ${animate ? 'transform transition-all duration-200 hover:scale-[1.02] hover:shadow-lg' : ''}
        ${className}
      `}
    >
      {children}
    </div>
  );
};

type CardHeaderProps = {
  className?: string;
  children: React.ReactNode;
  actions?: React.ReactNode;
};

export const CardHeader: React.FC<CardHeaderProps> = ({ 
  className = '', 
  children,
  actions 
}) => {
  return (
    <div className={`px-6 py-4 border-b border-gray-200 flex justify-between items-center ${className}`}>
      <div>{children}</div>
      {actions && <div>{actions}</div>}
    </div>
  );
};

type CardTitleProps = {
  className?: string;
  children: React.ReactNode;
  subtitle?: string;
};

export const CardTitle: React.FC<CardTitleProps> = ({ 
  className = '', 
  children,
  subtitle 
}) => {
  return (
    <div>
      <h3 className={`text-lg font-semibold text-gray-900 ${className}`}>
        {children}
      </h3>
      {subtitle && (
        <p className="mt-1 text-sm text-gray-500">{subtitle}</p>
      )}
    </div>
  );
};

type CardDescriptionProps = {
  className?: string;
  children: React.ReactNode;
};

export const CardDescription: React.FC<CardDescriptionProps> = ({ 
  className = '', 
  children 
}) => {
  return (
    <p className={`text-sm text-gray-500 mt-1 ${className}`}>
      {children}
    </p>
  );
};

type CardContentProps = {
  className?: string;
  children: React.ReactNode;
  padded?: boolean;
};

export const CardContent: React.FC<CardContentProps> = ({ 
  className = '', 
  children,
  padded = true 
}) => {
  return (
    <div className={`${padded ? 'px-6 py-4' : ''} ${className}`}>
      {children}
    </div>
  );
};

type CardFooterProps = {
  className?: string;
  children: React.ReactNode;
  variant?: 'default' | 'muted' | 'gradient';
};

export const CardFooter: React.FC<CardFooterProps> = ({ 
  className = '', 
  children,
  variant = 'default' 
}) => {
  const variants = {
    default: 'border-t border-gray-200 bg-gray-50',
    muted: 'border-t border-gray-100 bg-gray-25',
    gradient: 'border-t border-gray-200 bg-gradient-to-b from-gray-50 to-white'
  };

  return (
    <div className={`
      px-6 py-4 
      rounded-b-lg 
      ${variants[variant]}
      ${className}
    `}>
      {children}
    </div>
  );
};