import React from 'react';
import { X, CheckCircle, AlertCircle, Info, AlertTriangle } from 'lucide-react';

type ToastProps = {
  id: string;
  title: string;
  description?: string;
  type?: 'success' | 'error' | 'info' | 'warning';
  onClose: (id: string) => void;
};

export const Toast: React.FC<ToastProps> = ({
  id,
  title,
  description,
  type = 'info',
  onClose,
}) => {
  const variants = {
    info: {
      icon: <Info className="h-5 w-5 text-blue-500" />,
      className: 'border-blue-200 bg-blue-50',
    },
    success: {
      icon: <CheckCircle className="h-5 w-5 text-green-500" />,
      className: 'border-green-200 bg-green-50',
    },
    warning: {
      icon: <AlertTriangle className="h-5 w-5 text-amber-500" />,
      className: 'border-amber-200 bg-amber-50',
    },
    error: {
      icon: <AlertCircle className="h-5 w-5 text-red-500" />,
      className: 'border-red-200 bg-red-50',
    },
  };

  const { icon, className } = variants[type];

  return (
    <div
      className={`pointer-events-auto w-full max-w-sm rounded-lg border p-4 shadow-md ${className} animate-in slide-in-from-right-full`}
    >
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0">{icon}</div>
        <div className="flex-1">
          <div className="mb-1 font-medium">{title}</div>
          {description && <div className="text-sm text-gray-500">{description}</div>}
        </div>
        <button
          onClick={() => onClose(id)}
          className="flex-shrink-0 rounded-md p-1 text-gray-400 hover:bg-gray-200 hover:text-gray-500"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};