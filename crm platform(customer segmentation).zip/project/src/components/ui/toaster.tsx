import React, { useState, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { Toast } from './toast';

type ToastType = 'info' | 'success' | 'warning' | 'error';

export type ToastProps = {
  id: string;
  title: string;
  description?: string;
  type?: ToastType;
};

type ToastContextType = {
  toast: (props: Omit<ToastProps, 'id'>) => void;
  dismiss: (id: string) => void;
};

export const ToastContext = React.createContext<ToastContextType>({
  toast: () => {},
  dismiss: () => {},
});

export const useToast = () => React.useContext(ToastContext);

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastProps[]>([]);

  const toast = useCallback((props: Omit<ToastProps, 'id'>) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prevToasts) => [...prevToasts, { id, ...props }]);

    // Auto dismiss after 5 seconds
    setTimeout(() => {
      setToasts((prevToasts) => prevToasts.filter((toast) => toast.id !== id));
    }, 5000);
  }, []);

  const dismiss = useCallback((id: string) => {
    setToasts((prevToasts) => prevToasts.filter((toast) => toast.id !== id));
  }, []);

  return (
    <ToastContext.Provider value={{ toast, dismiss }}>
      {children}
      <Toaster toasts={toasts} dismiss={dismiss} />
    </ToastContext.Provider>
  );
};

export const Toaster: React.FC<{
  toasts?: ToastProps[];
  dismiss?: (id: string) => void;
}> = ({ toasts = [], dismiss = () => {} }) => {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    return () => setMounted(false);
  }, []);

  if (!mounted) return null;

  // Create portal to render toasts at the top level of the DOM
  return createPortal(
    <div className="fixed top-0 right-0 z-50 flex flex-col gap-2 p-4 max-w-sm w-full">
      {toasts.map((toast) => (
        <Toast
          key={toast.id}
          id={toast.id}
          title={toast.title}
          description={toast.description}
          type={toast.type}
          onClose={dismiss}
        />
      ))}
    </div>,
    document.body
  );
};