import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  Clock, 
  Users, 
  Mail, 
  AlertTriangle,
  CheckCircle,
  XCircle,
  BarChart3, 
  Download,
  MessageSquare 
} from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';

const CampaignDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  
  // Mock campaign data - in a real app, this would come from an API
  const campaign = {
    id,
    name: 'Summer Sale Announcement',
    status: 'completed',
    date: '2025-06-15',
    audience: {
      size: 3245,
      segmentName: 'High Value Customers (Spend > $500)',
    },
    delivery: {
      sent: 3102,
      failed: 143,
      opened: 1876,
      clicked: 942,
    },
    message: {
      subject: 'Summer Sale: Up to 40% Off!',
      preview: 'Hi {{name}}, we\'re excited to announce our biggest summer sale with up to 40% off on select items!',
    },
    insights: [
      'Campaign reached 95.6% of the audience successfully',
      'Open rate is 60.5% which is 15.2% higher than average',
      'Click-through rate is 30.4% which is 8.7% higher than average',
      'Most engaged segment was customers who purchased in the last 30 days',
    ],
  };
  
  // Calculate delivery rates
  const deliveryRate = Math.round((campaign.delivery.sent / campaign.audience.size) * 100);
  const openRate = Math.round((campaign.delivery.opened / campaign.delivery.sent) * 100);
  const clickRate = Math.round((campaign.delivery.clicked / campaign.delivery.sent) * 100);
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-4">
        <div>
          <Link to="/campaigns" className="flex items-center text-gray-500 hover:text-gray-700 mb-2">
            <ArrowLeft size={16} className="mr-1" />
            <span>Back to Campaigns</span>
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">{campaign.name}</h1>
          <div className="flex items-center gap-3 mt-1 text-sm text-gray-500">
            <div className="flex items-center">
              <Clock size={16} className="mr-1" />
              <span>{new Date(campaign.date).toLocaleDateString()}</span>
            </div>
            <div className="flex items-center">
              <Users size={16} className="mr-1" />
              <span>{campaign.audience.size.toLocaleString()} recipients</span>
            </div>
            <div className="flex items-center">
              <Mail size={16} className="mr-1" />
              <span>{deliveryRate}% delivered</span>
            </div>
          </div>
        </div>
        
        <div className="mt-4 md:mt-0 flex gap-2">
          <Button 
            variant="outline" 
            leftIcon={<Download size={16} />}
          >
            Export Results
          </Button>
          <Button 
            leftIcon={<MessageSquare size={16} />}
          >
            Clone Campaign
          </Button>
        </div>
      </div>
      
      {/* Campaign Status Banner */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-center justify-between">
        <div className="flex items-center">
          <CheckCircle className="text-blue-500 mr-2" size={20} />
          <div>
            <h3 className="font-medium">Campaign Completed</h3>
            <p className="text-sm text-gray-600">All messages have been processed and delivered</p>
          </div>
        </div>
        <div>
          <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
            Completed
          </span>
        </div>
      </div>
      
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Audience Size</p>
                <p className="text-3xl font-bold mt-1">{campaign.audience.size.toLocaleString()}</p>
              </div>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
            <p className="text-xs text-gray-500 mt-2">{campaign.audience.segmentName}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Delivered</p>
                <p className="text-3xl font-bold mt-1">
                  {campaign.delivery.sent.toLocaleString()} <span className="text-lg text-green-600">{deliveryRate}%</span>
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
            <p className="text-xs text-gray-500 mt-2">
              {campaign.delivery.failed.toLocaleString()} failed deliveries
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Open Rate</p>
                <p className="text-3xl font-bold mt-1">{openRate}%</p>
              </div>
              <Mail className="h-8 w-8 text-purple-500" />
            </div>
            <p className="text-xs text-gray-500 mt-2">
              {campaign.delivery.opened.toLocaleString()} opens
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Click Rate</p>
                <p className="text-3xl font-bold mt-1">{clickRate}%</p>
              </div>
              <BarChart3 className="h-8 w-8 text-indigo-500" />
            </div>
            <p className="text-xs text-gray-500 mt-2">
              {campaign.delivery.clicked.toLocaleString()} clicks
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* Message Preview and Performance Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Message Preview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
              <div className="border-b border-gray-200 pb-2 mb-4">
                <p className="font-medium">{campaign.message.subject}</p>
                <p className="text-xs text-gray-500 mt-1">Sent from: noreply@yourcompany.com</p>
              </div>
              <div className="prose prose-sm max-w-none">
                <p>{campaign.message.preview}</p>
                <p className="mt-4">View this email in your browser.</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>AI-Generated Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {campaign.insights.map((insight, index) => (
                <div key={index} className="flex items-start gap-2">
                  {index % 2 === 0 ? (
                    <CheckCircle size={18} className="text-green-500 mt-0.5 flex-shrink-0" />
                  ) : (
                    <AlertTriangle size={18} className="text-amber-500 mt-0.5 flex-shrink-0" />
                  )}
                  <p className="text-sm">{insight}</p>
                </div>
              ))}
            </div>
            
            <div className="mt-6">
              <h4 className="font-medium mb-2">Recommendations</h4>
              <ul className="text-sm space-y-2">
                <li className="flex items-start gap-2">
                  <div className="rounded-full bg-blue-100 p-1 mt-0.5">
                    <MessageSquare size={14} className="text-blue-600" />
                  </div>
                  <span>Follow up with customers who clicked but didn\'t purchase</span>
                </li>
                <li className="flex items-start gap-2">
                  <div className="rounded-full bg-blue-100 p-1 mt-0.5">
                    <Users size={14} className="text-blue-600" />
                  </div>
                  <span>Create a similar segment for your next promotion</span>
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Delivery Issues */}
      <Card>
        <CardHeader>
          <CardTitle>Delivery Issues</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border border-red-200 bg-red-50 p-4">
            <div className="flex items-start">
              <XCircle size={20} className="text-red-500 mt-0.5 mr-2 flex-shrink-0" />
              <div>
                <h4 className="font-medium text-red-800">143 Failed Deliveries</h4>
                <p className="text-sm text-red-700 mt-1">
                  There were some delivery issues with this campaign. Here\'s a summary of the problems:
                </p>
                <ul className="mt-2 space-y-1 text-sm text-red-700">
                  <li>• 87 bounced emails (invalid addresses)</li>
                  <li>• 32 rejected (spam complaints)</li>
                  <li>• 24 delivery failures (mailbox full, temporary server issues)</li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="mt-4">
            <Button variant="outline">Download Failed Delivery Report</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CampaignDetail;