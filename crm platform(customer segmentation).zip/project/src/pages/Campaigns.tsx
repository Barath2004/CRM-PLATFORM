import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Search, 
  Filter, 
  Plus, 
  ChevronDown, 
  Check,
  MessageSquare,
  Calendar,
  Mail,
  Users
} from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';

// Campaign status component
const CampaignStatus = ({ status }: { status: 'active' | 'completed' | 'draft' | 'failed' }) => {
  const statusStyles = {
    active: 'bg-green-100 text-green-800',
    completed: 'bg-blue-100 text-blue-800',
    draft: 'bg-gray-100 text-gray-800',
    failed: 'bg-red-100 text-red-800',
  };

  return (
    <span
      className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${statusStyles[status]}`}
    >
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
};

type Campaign = {
  id: string;
  name: string;
  status: 'active' | 'completed' | 'draft' | 'failed';
  audience: number;
  delivered: number;
  failed: number;
  date: string;
  type: 'promotional' | 'transactional' | 'newsletter' | 'welcome';
};

const Campaigns: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [showStatusDropdown, setShowStatusDropdown] = useState(false);
  const [showTypeDropdown, setShowTypeDropdown] = useState(false);

  // Mock campaigns data
  const campaignsData: Campaign[] = [
    {
      id: 'camp-001',
      name: 'Summer Sale Announcement',
      status: 'active',
      audience: 3245,
      delivered: 3102,
      failed: 143,
      date: '2025-06-15',
      type: 'promotional',
    },
    {
      id: 'camp-002',
      name: 'New Product Launch',
      status: 'completed',
      audience: 1876,
      delivered: 1845,
      failed: 31,
      date: '2025-06-10',
      type: 'promotional',
    },
    {
      id: 'camp-003',
      name: 'Monthly Newsletter - June',
      status: 'completed',
      audience: 5230,
      delivered: 5187,
      failed: 43,
      date: '2025-06-01',
      type: 'newsletter',
    },
    {
      id: 'camp-004',
      name: 'Customer Feedback Survey',
      status: 'failed',
      audience: 2100,
      delivered: 1245,
      failed: 855,
      date: '2025-05-28',
      type: 'transactional',
    },
    {
      id: 'camp-005',
      name: 'Welcome Series - New Users',
      status: 'active',
      audience: 872,
      delivered: 872,
      failed: 0,
      date: '2025-05-20',
      type: 'welcome',
    },
    {
      id: 'camp-006',
      name: 'Discount for Inactive Customers',
      status: 'draft',
      audience: 1543,
      delivered: 0,
      failed: 0,
      date: '2025-06-20',
      type: 'promotional',
    },
  ];

  // Filter campaigns based on search and filters
  const filteredCampaigns = campaignsData.filter((campaign) => {
    const matchesSearch = campaign.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || campaign.status === statusFilter;
    const matchesType = typeFilter === 'all' || campaign.type === typeFilter;
    return matchesSearch && matchesStatus && matchesType;
  });

  // Campaign type icon mapping
  const typeIcons = {
    promotional: <Mail className="h-5 w-5 text-purple-500" />,
    transactional: <MessageSquare className="h-5 w-5 text-blue-500" />,
    newsletter: <Calendar className="h-5 w-5 text-green-500" />,
    welcome: <Users className="h-5 w-5 text-amber-500" />,
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Campaigns</h1>
          <p className="text-gray-500">Manage and track your marketing campaigns</p>
        </div>
        
        <div className="mt-4 md:mt-0">
          <Link to="/create-segment">
            <Button leftIcon={<Plus size={16} />}>Create Campaign</Button>
          </Link>
        </div>
      </div>
      
      {/* Filters and search */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-grow">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search campaigns..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="block w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-primary focus:border-primary"
          />
        </div>
        
        <div className="flex gap-2">
          <div className="relative">
            <button
              className="flex items-center gap-1 px-4 py-2 border border-gray-300 rounded-md text-sm text-gray-700 bg-white hover:bg-gray-50"
              onClick={() => setShowStatusDropdown(!showStatusDropdown)}
            >
              <Filter size={16} className="mr-1" />
              Status: {statusFilter === 'all' ? 'All' : statusFilter.charAt(0).toUpperCase() + statusFilter.slice(1)}
              <ChevronDown size={16} className="ml-1" />
            </button>
            
            {showStatusDropdown && (
              <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg py-1 z-20 border border-gray-200">
                {['all', 'active', 'completed', 'draft', 'failed'].map((status) => (
                  <button
                    key={status}
                    className="flex items-center w-full px-4 py-2 text-sm text-left text-gray-700 hover:bg-gray-100"
                    onClick={() => {
                      setStatusFilter(status);
                      setShowStatusDropdown(false);
                    }}
                  >
                    {statusFilter === status && <Check size={16} className="mr-2" />}
                    <span className={statusFilter === status ? 'font-medium' : ''}>
                      {status === 'all' ? 'All' : status.charAt(0).toUpperCase() + status.slice(1)}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
          
          <div className="relative">
            <button
              className="flex items-center gap-1 px-4 py-2 border border-gray-300 rounded-md text-sm text-gray-700 bg-white hover:bg-gray-50"
              onClick={() => setShowTypeDropdown(!showTypeDropdown)}
            >
              Type: {typeFilter === 'all' ? 'All' : typeFilter.charAt(0).toUpperCase() + typeFilter.slice(1)}
              <ChevronDown size={16} className="ml-1" />
            </button>
            
            {showTypeDropdown && (
              <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg py-1 z-20 border border-gray-200">
                {['all', 'promotional', 'transactional', 'newsletter', 'welcome'].map((type) => (
                  <button
                    key={type}
                    className="flex items-center w-full px-4 py-2 text-sm text-left text-gray-700 hover:bg-gray-100"
                    onClick={() => {
                      setTypeFilter(type);
                      setShowTypeDropdown(false);
                    }}
                  >
                    {typeFilter === type && <Check size={16} className="mr-2" />}
                    <span className={typeFilter === type ? 'font-medium' : ''}>
                      {type === 'all' ? 'All' : type.charAt(0).toUpperCase() + type.slice(1)}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Campaigns List */}
      <div className="space-y-4">
        {filteredCampaigns.length === 0 ? (
          <Card>
            <CardContent className="py-10">
              <div className="text-center">
                <MessageSquare className="h-12 w-12 text-gray-300 mx-auto" />
                <h3 className="mt-2 text-lg font-medium text-gray-900">No campaigns found</h3>
                <p className="mt-1 text-gray-500">
                  {searchTerm || statusFilter !== 'all' || typeFilter !== 'all'
                    ? 'Try adjusting your filters or search term'
                    : "You haven't created any campaigns yet"}
                </p>
                <div className="mt-6">
                  <Link to="/create-segment">
                    <Button leftIcon={<Plus size={16} />}>Create Campaign</Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          filteredCampaigns.map((campaign) => (
            <Card key={campaign.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-0">
                <Link to={`/campaigns/${campaign.id}`} className="block p-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-gray-100 rounded-lg">
                        {typeIcons[campaign.type]}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-medium text-gray-900">{campaign.name}</h3>
                          <CampaignStatus status={campaign.status} />
                        </div>
                        <div className="mt-1 flex items-center gap-4 text-sm text-gray-500">
                          <span>Audience: {campaign.audience.toLocaleString()}</span>
                          <span>•</span>
                          <span>Date: {new Date(campaign.date).toLocaleDateString()}</span>
                          <span>•</span>
                          <span className="capitalize">{campaign.type}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-4 sm:mt-0 flex items-center gap-4">
                      {campaign.status !== 'draft' && (
                        <>
                          <div className="text-center">
                            <p className="text-sm font-medium text-green-600">
                              {campaign.delivered.toLocaleString()}
                            </p>
                            <p className="text-xs text-gray-500">Delivered</p>
                          </div>
                          <div className="text-center">
                            <p className="text-sm font-medium text-red-600">
                              {campaign.failed.toLocaleString()}
                            </p>
                            <p className="text-xs text-gray-500">Failed</p>
                          </div>
                          <div className="text-center">
                            <p className="text-sm font-medium">
                              {campaign.delivered > 0
                                ? `${Math.round((campaign.delivered / campaign.audience) * 100)}%`
                                : '0%'}
                            </p>
                            <p className="text-xs text-gray-500">Success Rate</p>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </Link>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default Campaigns;