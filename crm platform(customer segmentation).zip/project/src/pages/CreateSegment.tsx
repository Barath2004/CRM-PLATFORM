import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Plus, 
  Trash2, 
  Users, 
  ArrowRight, 
  RefreshCw, 
  Info, 
  Zap,
  MessageSquare,
  Wand2
} from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '../components/ui/card';
import { useToast } from '../components/ui/toaster';
import { v4 as uuidv4 } from 'uuid';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';

// Types for rule engine
type RuleGroup = {
  id: string;
  operator: 'AND' | 'OR';
  rules: Rule[];
};

type Rule = {
  id: string;
  field: string;
  condition: string;
  value: string | number;
};

type FieldOption = {
  value: string;
  label: string;
  type: 'text' | 'number' | 'date' | 'select';
  conditions: {
    value: string;
    label: string;
  }[];
  options?: {
    value: string;
    label: string;
  }[];
};

// Available fields for segmentation
const fieldOptions: FieldOption[] = [
  {
    value: 'spend',
    label: 'Total Spend',
    type: 'number',
    conditions: [
      { value: '>', label: 'Greater than' },
      { value: '<', label: 'Less than' },
      { value: '=', label: 'Equal to' },
      { value: '>=', label: 'Greater than or equal to' },
      { value: '<=', label: 'Less than or equal to' },
    ],
  },
  {
    value: 'visits',
    label: 'Number of Visits',
    type: 'number',
    conditions: [
      { value: '>', label: 'Greater than' },
      { value: '<', label: 'Less than' },
      { value: '=', label: 'Equal to' },
      { value: '>=', label: 'Greater than or equal to' },
      { value: '<=', label: 'Less than or equal to' },
    ],
  },
  {
    value: 'last_purchase',
    label: 'Last Purchase Date',
    type: 'date',
    conditions: [
      { value: 'before', label: 'Before' },
      { value: 'after', label: 'After' },
      { value: 'between', label: 'Between' },
      { value: 'days_ago', label: 'Days ago' },
    ],
  },
  {
    value: 'status',
    label: 'Customer Status',
    type: 'select',
    conditions: [
      { value: '=', label: 'Is' },
      { value: '!=', label: 'Is not' },
    ],
    options: [
      { value: 'active', label: 'Active' },
      { value: 'inactive', label: 'Inactive' },
      { value: 'new', label: 'New' },
    ],
  },
  {
    value: 'products',
    label: 'Purchased Products',
    type: 'select',
    conditions: [
      { value: 'contains', label: 'Contains' },
      { value: 'not_contains', label: 'Does not contain' },
    ],
    options: [
      { value: 'electronics', label: 'Electronics' },
      { value: 'clothing', label: 'Clothing' },
      { value: 'home', label: 'Home & Kitchen' },
      { value: 'beauty', label: 'Beauty & Personal Care' },
    ],
  },
];

const CreateSegment: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // State for segment builder
  const [segmentName, setSegmentName] = useState('');
  const [ruleGroup, setRuleGroup] = useState<RuleGroup>({
    id: uuidv4(),
    operator: 'AND',
    rules: [
      {
        id: uuidv4(),
        field: 'spend',
        condition: '>',
        value: 1000,
      },
    ],
  });
  
  // State for campaign details
  const [campaignName, setCampaignName] = useState('');
  const [campaignMessage, setCampaignMessage] = useState('');
  const [messagePreview, setMessagePreview] = useState('');
  
  // State for audience preview
  const [audienceSize, setAudienceSize] = useState<number | null>(null);
  const [isLoadingPreview, setIsLoadingPreview] = useState(false);
  
  // State for AI integration
  const [naturalLanguageInput, setNaturalLanguageInput] = useState('');
  const [isProcessingNL, setIsProcessingNL] = useState(false);
  const [messageSuggestions, setMessageSuggestions] = useState<string[]>([]);
  const [isGeneratingSuggestions, setIsGeneratingSuggestions] = useState(false);
  
  // State for form submission
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Add a new rule to the rule group
  const addRule = () => {
    const newRules = [...ruleGroup.rules];
    newRules.push({
      id: uuidv4(),
      field: 'visits',
      condition: '>',
      value: 0,
    });
    setRuleGroup({
      ...ruleGroup,
      rules: newRules,
    });
  };

  // Remove a rule from the rule group
  const removeRule = (id: string) => {
    if (ruleGroup.rules.length === 1) {
      toast({
        title: 'Cannot remove rule',
        description: 'At least one rule is required for segment creation.',
        type: 'warning',
      });
      return;
    }
    
    const newRules = ruleGroup.rules.filter((rule) => rule.id !== id);
    setRuleGroup({
      ...ruleGroup,
      rules: newRules,
    });
  };

  // Update a rule in the rule group
  const updateRule = (id: string, field: string, value: any) => {
    const newRules = ruleGroup.rules.map((rule) => {
      if (rule.id === id) {
        // If changing the field, reset condition and value
        if (field === 'field') {
          const selectedField = fieldOptions.find((option) => option.value === value);
          return {
            ...rule,
            [field]: value,
            condition: selectedField?.conditions[0].value || '=',
            value: selectedField?.type === 'number' ? 0 : 
                  selectedField?.type === 'date' ? '' :
                  selectedField?.options ? selectedField.options[0].value : '',
          };
        }
        return { ...rule, [field]: value };
      }
      return rule;
    });
    
    setRuleGroup({
      ...ruleGroup,
      rules: newRules,
    });
  };

  // Toggle the operator (AND/OR) for the rule group
  const toggleOperator = () => {
    setRuleGroup({
      ...ruleGroup,
      operator: ruleGroup.operator === 'AND' ? 'OR' : 'AND',
    });
  };

  // On drag end handler for drag and drop functionality
  const onDragEnd = (result: any) => {
    // Dropped outside the list
    if (!result.destination) {
      return;
    }

    const items = Array.from(ruleGroup.rules);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setRuleGroup({
      ...ruleGroup,
      rules: items,
    });
  };

  // Preview audience size
  const previewAudience = () => {
    setIsLoadingPreview(true);
    
    // Simulating API call to get audience size
    setTimeout(() => {
      // Random audience size between 100 and 5000
      const size = Math.floor(Math.random() * (5000 - 100 + 1)) + 100;
      setAudienceSize(size);
      setIsLoadingPreview(false);
      
      toast({
        title: 'Audience Preview',
        description: `Your segment contains ${size.toLocaleString()} customers.`,
        type: 'info',
      });
    }, 1000);
  };

  // Process natural language input to create rules
  const processNaturalLanguage = async () => {
    if (!naturalLanguageInput.trim()) {
      toast({
        title: 'Input Required',
        description: 'Please enter a description of your target audience.',
        type: 'warning',
      });
      return;
    }
    
    setIsProcessingNL(true);
    
    try {
      // Simulated AI processing
      // In a real app, this would call an AI API (OpenAI, Vertex AI, etc.)
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Create rule group based on NL input (simplified logic for demo)
      // In reality, this would be parsed by an AI model
      const newRuleGroup: RuleGroup = {
        id: uuidv4(),
        operator: 'AND',
        rules: [],
      };
      
      const input = naturalLanguageInput.toLowerCase();
      
      // Simple pattern matching (would be AI-powered in real app)
      if (input.includes('spend') || input.includes('spent')) {
        const amount = input.match(/\d+/) ? parseInt(input.match(/\d+/)?.[0] || '1000') : 1000;
        newRuleGroup.rules.push({
          id: uuidv4(),
          field: 'spend',
          condition: '>',
          value: amount,
        });
      }
      
      if (input.includes('visit') || input.includes('visits')) {
        const visits = input.match(/\d+\s+visits/) ? 
          parseInt(input.match(/(\d+)\s+visits/)?.[1] || '3') : 3;
        
        newRuleGroup.rules.push({
          id: uuidv4(),
          field: 'visits',
          condition: '<',
          value: visits,
        });
      }
      
      if (input.includes('inactive') || input.includes('active')) {
        newRuleGroup.rules.push({
          id: uuidv4(),
          field: 'status',
          condition: '=',
          value: input.includes('inactive') ? 'inactive' : 'active',
        });
      }
      
      if (input.includes('days') || input.includes('months')) {
        const days = input.includes('months') ? 
          (parseInt(input.match(/(\d+)\s+months/)?.[1] || '1') * 30) : 
          parseInt(input.match(/(\d+)\s+days/)?.[1] || '30');
        
        newRuleGroup.rules.push({
          id: uuidv4(),
          field: 'last_purchase',
          condition: 'days_ago',
          value: days,
        });
      }
      
      // Determine operator based on "and" or "or" in the input
      if (input.includes(' or ')) {
        newRuleGroup.operator = 'OR';
      }
      
      // Ensure at least one rule
      if (newRuleGroup.rules.length === 0) {
        newRuleGroup.rules.push({
          id: uuidv4(),
          field: 'spend',
          condition: '>',
          value: 1000,
        });
      }
      
      setRuleGroup(newRuleGroup);
      
      toast({
        title: 'Rules Generated',
        description: 'Segment rules have been created from your description.',
        type: 'success',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to process natural language input. Please try again.',
        type: 'error',
      });
    } finally {
      setIsProcessingNL(false);
    }
  };

  // Generate message suggestions
  const generateMessageSuggestions = async () => {
    if (!campaignName.trim()) {
      toast({
        title: 'Campaign Name Required',
        description: 'Please enter a campaign name to generate message suggestions.',
        type: 'warning',
      });
      return;
    }
    
    setIsGeneratingSuggestions(true);
    
    try {
      // Simulated AI message generation
      // In a real app, this would call an AI API
      await new Promise(resolve => setTimeout(resolve, 1800));
      
      // Generate messages based on campaign name and rules
      const targetAudience = ruleGroup.rules.map(rule => {
        const field = fieldOptions.find(f => f.value === rule.field);
        const condition = field?.conditions.find(c => c.value === rule.condition);
        
        if (field?.type === 'select' && field.options) {
          const option = field.options.find(o => o.value === rule.value);
          return `${field.label} ${condition?.label} ${option?.label}`;
        }
        
        return `${field?.label} ${condition?.label} ${rule.value}`;
      }).join(` ${ruleGroup.operator} `);
      
      // Generate message suggestions
      const suggestions = [
        `Hi {name}, we've missed you! Enjoy 15% off your next purchase with code WELCOME15.`,
        `{name}, here's a special offer just for you: 10% discount on your next order!`,
        `We noticed you haven't shopped with us in a while, {name}. Come back and get 20% off today!`,
      ];
      
      setMessageSuggestions(suggestions);
      
      toast({
        title: 'Message Suggestions Generated',
        description: 'Choose one of the suggested messages or write your own.',
        type: 'success',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to generate message suggestions. Please try again.',
        type: 'error',
      });
    } finally {
      setIsGeneratingSuggestions(false);
    }
  };

  // Create campaign and save segment
  const createCampaign = async () => {
    if (!segmentName.trim()) {
      toast({
        title: 'Segment Name Required',
        description: 'Please enter a name for your segment.',
        type: 'warning',
      });
      return;
    }
    
    if (!campaignName.trim()) {
      toast({
        title: 'Campaign Name Required',
        description: 'Please enter a name for your campaign.',
        type: 'warning',
      });
      return;
    }
    
    if (!campaignMessage.trim()) {
      toast({
        title: 'Message Required',
        description: 'Please enter a message for your campaign.',
        type: 'warning',
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Simulated API call to create campaign
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: 'Campaign Created',
        description: 'Your segment and campaign have been created successfully.',
        type: 'success',
      });
      
      // Redirect to campaigns page
      navigate('/campaigns');
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to create campaign. Please try again.',
        type: 'error',
      });
      setIsSubmitting(false);
    }
  };

  // Update message preview when campaign message changes
  useEffect(() => {
    if (campaignMessage) {
      // Replace {name} placeholder with "Customer"
      const preview = campaignMessage.replace(/{name}/g, 'Customer');
      setMessagePreview(preview);
    } else {
      setMessagePreview('');
    }
  }, [campaignMessage]);

  const getFieldLabel = (fieldValue: string): string => {
    const field = fieldOptions.find(option => option.value === fieldValue);
    return field?.label || fieldValue;
  };

  const getConditionLabel = (fieldValue: string, conditionValue: string): string => {
    const field = fieldOptions.find(option => option.value === fieldValue);
    const condition = field?.conditions.find(option => option.value === conditionValue);
    return condition?.label || conditionValue;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Create Customer Segment</h1>
        <p className="text-gray-500">Define your target audience with specific criteria</p>
      </div>
      
      {/* AI Natural Language Input */}
      <Card className="border-blue-100 bg-blue-50/50">
        <CardHeader>
          <CardTitle className="flex items-center text-blue-700">
            <Wand2 className="mr-2 h-5 w-5" />
            AI-Powered Segment Creation
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-blue-700">
            Describe your target audience in plain language, and we'll convert it to segment rules.
          </p>
          <div className="flex gap-2">
            <input
              type="text"
              value={naturalLanguageInput}
              onChange={(e) => setNaturalLanguageInput(e.target.value)}
              placeholder="e.g., People who spent over 10,000 and have less than 3 visits"
              className="flex-1 px-4 py-2 border border-blue-200 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              disabled={isProcessingNL}
            />
            <Button
              onClick={processNaturalLanguage}
              isLoading={isProcessingNL}
              leftIcon={<Zap size={16} />}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Generate Rules
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {/* Segment Builder */}
      <Card>
        <CardHeader>
          <CardTitle>Segment Builder</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <label htmlFor="segmentName" className="block text-sm font-medium text-gray-700 mb-1">
              Segment Name
            </label>
            <input
              id="segmentName"
              type="text"
              value={segmentName}
              onChange={(e) => setSegmentName(e.target.value)}
              placeholder="e.g., High-Value Customers"
              className="w-full px-4 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-primary focus:border-primary"
            />
          </div>
          
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-gray-700">Define Rules</h3>
              <button
                onClick={toggleOperator}
                className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${
                  ruleGroup.operator === 'AND'
                    ? 'bg-indigo-100 text-indigo-800 hover:bg-indigo-200'
                    : 'bg-orange-100 text-orange-800 hover:bg-orange-200'
                }`}
              >
                Match {ruleGroup.operator === 'AND' ? 'ALL' : 'ANY'} Conditions
              </button>
            </div>
            
            <DragDropContext onDragEnd={onDragEnd}>
              <Droppable droppableId="droppable-rules">
                {(provided) => (
                  <div
                    {...provided.droppableProps}
                    ref={provided.innerRef}
                    className="space-y-3"
                  >
                    {ruleGroup.rules.map((rule, index) => {
                      const selectedField = fieldOptions.find(
                        (option) => option.value === rule.field
                      );
                      
                      return (
                        <Draggable 
                          key={rule.id} 
                          draggableId={rule.id} 
                          index={index}
                        >
                          {(provided) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              className="flex flex-wrap items-center gap-3 p-3 bg-white border border-gray-200 rounded-lg shadow-sm"
                            >
                              <div
                                {...provided.dragHandleProps}
                                className="p-1 text-gray-400 cursor-move hover:text-gray-600"
                              >
                                ⋮⋮
                              </div>
                              
                              {index > 0 && (
                                <div className="px-2 py-1 text-xs font-medium text-gray-500 bg-gray-100 rounded">
                                  {ruleGroup.operator}
                                </div>
                              )}
                              
                              <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-3">
                                <select
                                  value={rule.field}
                                  onChange={(e) => updateRule(rule.id, 'field', e.target.value)}
                                  className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-primary focus:border-primary"
                                >
                                  {fieldOptions.map((option) => (
                                    <option key={option.value} value={option.value}>
                                      {option.label}
                                    </option>
                                  ))}
                                </select>
                                
                                <select
                                  value={rule.condition}
                                  onChange={(e) => updateRule(rule.id, 'condition', e.target.value)}
                                  className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-primary focus:border-primary"
                                >
                                  {selectedField?.conditions.map((option) => (
                                    <option key={option.value} value={option.value}>
                                      {option.label}
                                    </option>
                                  ))}
                                </select>
                                
                                {selectedField?.type === 'select' && selectedField?.options ? (
                                  <select
                                    value={rule.value as string}
                                    onChange={(e) => updateRule(rule.id, 'value', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-primary focus:border-primary"
                                  >
                                    {selectedField.options.map((option) => (
                                      <option key={option.value} value={option.value}>
                                        {option.label}
                                      </option>
                                    ))}
                                  </select>
                                ) : selectedField?.type === 'number' ? (
                                  <input
                                    type="number"
                                    value={rule.value as number}
                                    onChange={(e) => updateRule(rule.id, 'value', Number(e.target.value))}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-primary focus:border-primary"
                                  />
                                ) : selectedField?.type === 'date' ? (
                                  rule.condition === 'days_ago' ? (
                                    <input
                                      type="number"
                                      value={rule.value as number}
                                      onChange={(e) => updateRule(rule.id, 'value', Number(e.target.value))}
                                      className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-primary focus:border-primary"
                                      placeholder="Number of days"
                                    />
                                  ) : (
                                    <input
                                      type="date"
                                      value={rule.value as string}
                                      onChange={(e) => updateRule(rule.id, 'value', e.target.value)}
                                      className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-primary focus:border-primary"
                                    />
                                  )
                                ) : (
                                  <input
                                    type="text"
                                    value={rule.value as string}
                                    onChange={(e) => updateRule(rule.id, 'value', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-primary focus:border-primary"
                                  />
                                )}
                              </div>
                              
                              <button
                                onClick={() => removeRule(rule.id)}
                                className="p-2 text-gray-400 hover:text-red-500 focus:outline-none"
                                aria-label="Remove rule"
                              >
                                <Trash2 size={16} />
                              </button>
                            </div>
                          )}
                        </Draggable>
                      );
                    })}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>
            
            <div className="mt-3 flex gap-2">
              <Button
                variant="outline"
                onClick={addRule}
                leftIcon={<Plus size={16} />}
                className="text-sm"
              >
                Add Rule
              </Button>
              
              <Button
                variant="outline"
                onClick={previewAudience}
                isLoading={isLoadingPreview}
                leftIcon={<Users size={16} />}
                className="text-sm"
              >
                Preview Audience
              </Button>
            </div>
          </div>
          
          {audienceSize !== null && (
            <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Users className="mr-2 h-5 w-5 text-blue-500" />
                  <span className="font-medium">Audience Size:</span>
                </div>
                <span className="text-xl font-bold">{audienceSize.toLocaleString()}</span>
              </div>
              <div className="mt-2 text-sm text-gray-500">
                {audienceSize < 100 ? (
                  <p>Small audience. Consider broadening your criteria for better reach.</p>
                ) : audienceSize > 3000 ? (
                  <p>Large audience. Consider narrowing your criteria for more targeted messaging.</p>
                ) : (
                  <p>Good audience size for an effective campaign.</p>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Campaign Details */}
      <Card>
        <CardHeader>
          <CardTitle>Campaign Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label htmlFor="campaignName" className="block text-sm font-medium text-gray-700 mb-1">
              Campaign Name
            </label>
            <input
              id="campaignName"
              type="text"
              value={campaignName}
              onChange={(e) => setCampaignName(e.target.value)}
              placeholder="e.g., Summer Sale Promotion"
              className="w-full px-4 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-primary focus:border-primary"
            />
          </div>
          
          <div>
            <div className="flex justify-between items-center mb-1">
              <label htmlFor="campaignMessage" className="block text-sm font-medium text-gray-700">
                Campaign Message
              </label>
              <Button
                variant="ghost"
                size="sm"
                onClick={generateMessageSuggestions}
                isLoading={isGeneratingSuggestions}
                leftIcon={<Zap size={14} />}
                className="h-8 text-xs"
              >
                Generate Suggestions
              </Button>
            </div>
            <textarea
              id="campaignMessage"
              value={campaignMessage}
              onChange={(e) => setCampaignMessage(e.target.value)}
              placeholder="e.g., Hi {name}, we have a special offer for you!"
              className="w-full px-4 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-primary focus:border-primary"
              rows={3}
            />
            <p className="mt-1 text-xs text-gray-500">
              Use {'{name}'} to personalize the message with the customer's name.
            </p>
          </div>
          
          {messageSuggestions.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-gray-700">Message Suggestions</h4>
              <div className="grid gap-2">
                {messageSuggestions.map((message, index) => (
                  <button
                    key={index}
                    onClick={() => setCampaignMessage(message)}
                    className="text-left p-3 border border-gray-200 rounded-md text-sm hover:bg-gray-50 transition-colors"
                  >
                    {message}
                  </button>
                ))}
              </div>
            </div>
          )}
          
          {messagePreview && (
            <div className="mt-4 p-4 bg-gray-50 border border-gray-200 rounded-lg">
              <h4 className="text-sm font-medium text-gray-700 mb-2">Message Preview</h4>
              <div className="p-3 bg-white border border-gray-200 rounded-md">
                <p className="text-sm">{messagePreview}</p>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between border-t pt-6">
          <Button
            variant="outline"
            onClick={() => navigate('/campaigns')}
          >
            Cancel
          </Button>
          <Button
            onClick={createCampaign}
            isLoading={isSubmitting}
            leftIcon={<ArrowRight size={16} />}
          >
            Create Campaign
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default CreateSegment;