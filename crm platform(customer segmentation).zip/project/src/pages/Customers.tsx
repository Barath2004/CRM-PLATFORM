import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  ChevronDown, 
  Check,
  User,
  Mail,
  Phone,
  MapPin,
  ShoppingBag,
  Calendar,
  MoreHorizontal,
  Download,
  UserPlus
} from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';

type CustomerStatus = 'active' | 'inactive' | 'new';

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  status: CustomerStatus;
  totalSpend: number;
  orders: number;
  lastPurchase: string;
  tags: string[];
}

const Customers: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showStatusDropdown, setShowStatusDropdown] = useState(false);
  
  // Mock customer data
  const customersData: Customer[] = [
    {
      id: 'cust-001',
      name: 'Alex Johnson',
      email: 'alex.johnson@example.com',
      phone: '+1 (555) 123-4567',
      location: 'New York, USA',
      status: 'active',
      totalSpend: 12450,
      orders: 8,
      lastPurchase: '2025-06-10',
      tags: ['high-value', 'frequent'],
    },
    {
      id: 'cust-002',
      name: 'Samantha Lee',
      email: 'sam.lee@example.com',
      phone: '+1 (555) 987-6543',
      location: 'San Francisco, USA',
      status: 'active',
      totalSpend: 8750,
      orders: 5,
      lastPurchase: '2025-06-05',
      tags: ['high-value'],
    },
    {
      id: 'cust-003',
      name: 'Michael Chen',
      email: 'michael.c@example.com',
      phone: '+1 (555) 456-7890',
      location: 'Chicago, USA',
      status: 'inactive',
      totalSpend: 3250,
      orders: 3,
      lastPurchase: '2025-02-22',
      tags: ['inactive'],
    },
    {
      id: 'cust-004',
      name: 'Emily Rodriguez',
      email: 'emily.r@example.com',
      phone: '+1 (555) 234-5678',
      location: 'Miami, USA',
      status: 'new',
      totalSpend: 850,
      orders: 1,
      lastPurchase: '2025-06-12',
      tags: ['new'],
    },
    {
      id: 'cust-005',
      name: 'David Kim',
      email: 'david.kim@example.com',
      phone: '+1 (555) 876-5432',
      location: 'Seattle, USA',
      status: 'active',
      totalSpend: 6200,
      orders: 4,
      lastPurchase: '2025-05-30',
      tags: ['returning'],
    },
    {
      id: 'cust-006',
      name: 'Olivia Martinez',
      email: 'olivia.m@example.com',
      phone: '+1 (555) 345-6789',
      location: 'Austin, USA',
      status: 'inactive',
      totalSpend: 1850,
      orders: 2,
      lastPurchase: '2025-01-15',
      tags: ['inactive'],
    },
  ];

  // Filter customers based on search and status filter
  const filteredCustomers = customersData.filter((customer) => {
    const matchesSearch = 
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.location.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || customer.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  // Status badge component
  const StatusBadge = ({ status }: { status: CustomerStatus }) => {
    const statusStyles = {
      active: 'bg-green-100 text-green-800',
      inactive: 'bg-gray-100 text-gray-800',
      new: 'bg-blue-100 text-blue-800',
    };

    return (
      <span
        className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${statusStyles[status]}`}
      >
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Customers</h1>
          <p className="text-gray-500">Manage and view your customer base</p>
        </div>
        
        <div className="mt-4 md:mt-0 flex gap-2">
          <Button
            variant="outline"
            leftIcon={<Download size={16} />}
          >
            Export
          </Button>
          <Button
            leftIcon={<UserPlus size={16} />}
          >
            Add Customer
          </Button>
        </div>
      </div>
      
      {/* Search and filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-grow">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search customers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="block w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-primary focus:border-primary"
          />
        </div>
        
        <div className="relative">
          <button
            className="flex items-center gap-1 px-4 py-2 border border-gray-300 rounded-md text-sm text-gray-700 bg-white hover:bg-gray-50"
            onClick={() => setShowStatusDropdown(!showStatusDropdown)}
          >
            <Filter size={16} className="mr-1" />
            Status: {statusFilter === 'all' ? 'All' : statusFilter.charAt(0).toUpperCase() + statusFilter.slice(1)}
            <ChevronDown size={16} className="ml-1" />
          </button>
          
          {showStatusDropdown && (
            <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg py-1 z-20 border border-gray-200">
              {['all', 'active', 'inactive', 'new'].map((status) => (
                <button
                  key={status}
                  className="flex items-center w-full px-4 py-2 text-sm text-left text-gray-700 hover:bg-gray-100"
                  onClick={() => {
                    setStatusFilter(status);
                    setShowStatusDropdown(false);
                  }}
                >
                  {statusFilter === status && <Check size={16} className="mr-2" />}
                  <span className={statusFilter === status ? 'font-medium' : ''}>
                    {status === 'all' ? 'All' : status.charAt(0).toUpperCase() + status.slice(1)}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
      
      {/* Customers List */}
      <Card>
        <CardHeader className="border-b">
          <CardTitle>Customer List</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 border-b">
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Customer
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Contact
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Total Spend
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Orders
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Last Purchase
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredCustomers.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-12 text-center">
                      <User className="h-12 w-12 text-gray-300 mx-auto" />
                      <p className="mt-2 text-lg font-medium text-gray-900">No customers found</p>
                      <p className="mt-1 text-gray-500">
                        {searchTerm || statusFilter !== 'all'
                          ? 'Try adjusting your filters or search term'
                          : "You haven't added any customers yet"}
                      </p>
                    </td>
                  </tr>
                ) : (
                  filteredCustomers.map((customer) => (
                    <tr key={customer.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="h-10 w-10 flex-shrink-0 rounded-full bg-gray-200 flex items-center justify-center text-gray-600">
                            {customer.name.charAt(0)}
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{customer.name}</div>
                            <div className="flex items-center text-xs text-gray-500">
                              <MapPin size={12} className="mr-1" />
                              {customer.location}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900 flex items-center">
                          <Mail size={14} className="mr-1" />
                          {customer.email}
                        </div>
                        <div className="text-sm text-gray-500 flex items-center mt-1">
                          <Phone size={14} className="mr-1" />
                          {customer.phone}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <StatusBadge status={customer.status} />
                        {customer.tags.length > 0 && (
                          <div className="mt-2 flex flex-wrap gap-1">
                            {customer.tags.map((tag) => (
                              <span
                                key={tag}
                                className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded text-xs"
                              >
                                {tag}
                              </span>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          ${customer.totalSpend.toLocaleString()}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900 flex items-center">
                          <ShoppingBag size={14} className="mr-1" />
                          {customer.orders}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900 flex items-center">
                          <Calendar size={14} className="mr-1" />
                          {new Date(customer.lastPurchase).toLocaleDateString()}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-center">
                        <button className="p-1 text-gray-400 hover:text-gray-700 focus:outline-none">
                          <MoreHorizontal size={18} />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Customers;