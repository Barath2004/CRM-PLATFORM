import React from 'react';
import { 
  Users, 
  MessageSquare, 
  Zap, 
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  BarChart3
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';

const Dashboard: React.FC = () => {
  // Mock data
  const stats = [
    {
      title: 'Total Customers',
      value: '3,582',
      change: '+14.5%',
      increasing: true,
      icon: <Users className="h-8 w-8 text-blue-500" />,
    },
    {
      title: 'Active Campaigns',
      value: '12',
      change: '+27.3%',
      increasing: true,
      icon: <MessageSquare className="h-8 w-8 text-purple-500" />,
    },
    {
      title: 'Delivery Rate',
      value: '94.2%',
      change: '-2.1%',
      increasing: false,
      icon: <Zap className="h-8 w-8 text-amber-500" />,
    },
    {
      title: 'Engagement',
      value: '28.5%',
      change: '+5.2%',
      increasing: true,
      icon: <TrendingUp className="h-8 w-8 text-green-500" />,
    },
  ];

  // Recent campaigns
  const recentCampaigns = [
    {
      id: 'camp-001',
      name: 'Summer Sale Promotion',
      date: '2 days ago',
      audience: 1245,
      delivered: 1198,
      failed: 47,
    },
    {
      id: 'camp-002',
      name: 'New Product Launch',
      date: '5 days ago',
      audience: 865,
      delivered: 842,
      failed: 23,
    },
    {
      id: 'camp-003',
      name: 'Customer Feedback',
      date: '1 week ago',
      audience: 2103,
      delivered: 1950,
      failed: 153,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-500">Welcome back to your CRM control center</p>
        </div>
        
        <div className="mt-4 md:mt-0 flex gap-2">
          <Button 
            variant="outline" 
            leftIcon={<BarChart3 size={16} />}
          >
            Analytics
          </Button>
          <Button 
            leftIcon={<MessageSquare size={16} />}
          >
            New Campaign
          </Button>
        </div>
      </div>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => (
          <Card key={index} className="transition-all hover:shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">{stat.title}</p>
                  <p className="text-3xl font-bold mt-1">{stat.value}</p>
                </div>
                <div>{stat.icon}</div>
              </div>
              
              <div className="flex items-center mt-4">
                {stat.increasing ? (
                  <ArrowUpRight className="h-4 w-4 text-green-500 mr-1" />
                ) : (
                  <ArrowDownRight className="h-4 w-4 text-red-500 mr-1" />
                )}
                <span
                  className={`text-sm font-medium ${
                    stat.increasing ? 'text-green-600' : 'text-red-600'
                  }`}
                >
                  {stat.change}
                </span>
                <span className="text-sm text-gray-500 ml-1">vs last month</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Campaigns</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentCampaigns.map((campaign) => (
                <div
                  key={campaign.id}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-gray-50 rounded-lg"
                >
                  <div className="mb-2 sm:mb-0">
                    <h4 className="font-medium text-gray-900">{campaign.name}</h4>
                    <p className="text-sm text-gray-500">{campaign.date}</p>
                  </div>
                  <div className="flex items-center space-x-4 text-sm">
                    <div className="text-center">
                      <p className="font-medium">{campaign.audience}</p>
                      <p className="text-xs text-gray-500">Audience</p>
                    </div>
                    <div className="text-center">
                      <p className="font-medium text-green-600">{campaign.delivered}</p>
                      <p className="text-xs text-gray-500">Delivered</p>
                    </div>
                    <div className="text-center">
                      <p className="font-medium text-red-600">{campaign.failed}</p>
                      <p className="text-xs text-gray-500">Failed</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 text-center">
              <Button variant="link">View all campaigns</Button>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Audience Insights</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px] flex items-center justify-center">
            <div className="text-center">
              <BarChart3 className="h-16 w-16 text-gray-300 mx-auto" />
              <p className="mt-2 text-gray-500">Audience analytics visualization</p>
              <p className="text-sm text-gray-400">Charts and detailed metrics will appear here</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;